# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.common import *
from resources.lib.modules.animate import *

params = get_params()
mode = None

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
artAddon     = 'script.j1.artwork'

#===============================================================================

selfAddon = xbmcaddon.Addon(id=addon_id)

try:
    datapath= xbmcvfs.translatePath(selfAddon.getAddonInfo('profile'))
except:
    datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))

plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.animate')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')

try:
    fanart = xbmcvfs.translatePath(os.path.join(home, 'fanart.jpg'))
    icon = xbmcvfs.translatePath(os.path.join(home, 'icon.png'))
except:
    fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
    icon = xbmc.translatePath(os.path.join(home, 'icon.png'))

mediapath = 'http://j1wizard.net/media/'

#===============================================================================

def Main():

	add_link_info('[B][COLORorange]== Ani-mate ==[/COLOR][/B]', icon, fanart)
	
	addDirMain('[COLOR white][B]Ani-mate: Toddlers[/B][/COLOR]',BASE,59,mediapath+'animate_toddlers.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Kids[/B][/COLOR]',BASE,50,mediapath+'animate_kids.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Anime[/B][/COLOR]',BASE,51,mediapath+'animate_anime.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Mixed[/B][/COLOR]',BASE,52,mediapath+'animate_mixed.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Scifi[/B][/COLOR]',BASE,53,mediapath+'animate_scifi.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Comedy[/B][/COLOR]',BASE,54,mediapath+'animate_comedy.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Heroes[/B][/COLOR]',BASE,55,mediapath+'animate_heroes.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Movies[/B][/COLOR]',BASE,56,mediapath+'animate_movies.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Action[/B][/COLOR]',BASE,57,mediapath+'animate_action.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Ani-mate: Cartoons[/B][/COLOR]',BASE,58,mediapath+'animate_cartoons.png',mediapath+'fanart.jpg')

	add_link_info('[B][COLORorange] [/COLOR][/B]', icon, fanart)

#==========================================================================================================

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def regex_get_all(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r

#====================================================
		
params=get_params()
url=None
name=None
mode = None
iconimage=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===== ANI-MATE =====

if mode == 50:
	Animate_Kids()
		
elif mode == 51:
	Animate_Anime()		
		
elif mode == 52:
	Animate_Mixed()

elif mode == 53:
	Animate_Scifi()
	
elif mode == 54:
	Animate_Comedy()

elif mode == 55:
	Animate_Heroes()

elif mode == 56:
	Animate_Movies()

elif mode == 57:
	Animate_Action()
	
elif mode == 58:
	Animate_Cartoons()

elif mode == 59:
	Animate_Toddlers()

elif mode == 60:
	Animate_Music()

elif mode==None:
	Main()
		
xbmcplugin.endOfDirectory(plugin_handle)
